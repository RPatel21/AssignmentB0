﻿using System.Globalization;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Diagnostics;

public class Player2Contoller : MonoBehaviour
{
    public float speed;
    public float force = 201.0f;
    private Rigidbody rb2;

    private int count2;
    private int wallCollissionCount2;
    private int playerCollissionCount2;

    public Text countText2;
    public Text winText2;
    public Text CollisionText;

    void Start()
    {
        rb2 = GetComponent<Rigidbody>();

        count2 = 0;
        SetCountText();
        winText2.text = "";
        CollisionText.text = "";
    }

    void FixedUpdate()
    {
        if (!(Input.GetKey(KeyCode.A) || Input.GetKey(KeyCode.D) || Input.GetKey(KeyCode.W) || Input.GetKey(KeyCode.S) || Input.GetKey(KeyCode.R)))
        {
            float moveHorizontal = Input.GetAxis("Horizontal");
            float moveVertical = Input.GetAxis("Vertical");

            Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
            rb2.AddForce(movement * speed);

            if (Input.GetKeyDown(KeyCode.R) && rb2.transform.position.y <= 0.6250001f) {
                Vector3 jump = new Vector3(0.0f, force, 0.0f);
                rb2.AddForce(jump);
            }
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pick Up"))
        {
            other.gameObject.SetActive(false);
            count2 = count2 + 1;
            SetCountText();
        }
    }

    void SetCountText()
    {
        int points = count2 * 10 - wallCollissionCount2 * 2 - playerCollissionCount2 * 4;
        if (points < 1) {
            count2 = 0;
            points = 0;
            wallCollissionCount2 = 0;
            playerCollissionCount2 = 0;
        }

        countText2.text = "Player 2 points: " + points.ToString();
        if (count2 >= 6)
        {
            winText2.text = "You Win!";
            Invoke("Restart", 2.0f);
        }
    }

    //If your GameObject starts to collide with another GameObject with a Collider
    void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.name == "North Walls" || collision.collider.name == "South Walls" || collision.collider.name == "East Walls" || collision.collider.name == "West Walls") {
            wallCollissionCount2 = wallCollissionCount2 + 1;
            this.SetCountText();
            CollisionText.text = "Collision with " + collision.collider.name;
        }

        if (collision.collider.name == "Player") {
            playerCollissionCount2 += 1;
            this.SetCountText();
            CollisionText.text = "Collision with Player 1";
        }
    }

    void Restart() {
        SceneManager.LoadScene("MiniGame");
    }
}
