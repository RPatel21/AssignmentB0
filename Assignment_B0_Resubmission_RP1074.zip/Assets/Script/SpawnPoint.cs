﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnPoint : MonoBehaviour
{
    public GameObject prefabpickups;
    public float repeatTime = 10f;

    void Start()
    {
        InvokeRepeating("Cubes", 10f, repeatTime);
    }

    void Cubes()
    {
        Instantiate(prefabpickups, transform.position, Quaternion.identity);
    }
}