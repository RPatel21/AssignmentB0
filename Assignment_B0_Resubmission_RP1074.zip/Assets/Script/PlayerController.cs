﻿using System.Globalization;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Reflection;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{

    public float speed;
    public float force = 200.0f;
    public Text countText;
    public Text winText;

    private Rigidbody rb;
    private int count;
    private int wallCollissionCount;
    private int playerCollissionCount;

    public Text timerText;
    public float timeRemaining = 122;
    public bool timerIsRunning = false;

    public Text AlertText;
    public Text CollisionText;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        count = 0;
        SetCountText();
        winText.text = "";

        // Starts the timer automatically
        timerIsRunning = true;
        AlertText.text = "";
        CollisionText.text = "";
    }

    void FixedUpdate()
    {        
        Player1Movement();
        if (timerIsRunning)
        {
            setTimer();
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pick Up"))
        {
            other.gameObject.SetActive(false);
            count = count + 1;
            SetCountText();            
        }
    }

    void SetCountText()
    {
        int points = count * 10 - wallCollissionCount * 2 - playerCollissionCount * 4;
        if (points < 1)
        {
            count = 0;
            points = 0;
            wallCollissionCount = 0;
            playerCollissionCount = 0;
        }
        countText.text = "Player 1 points: " + points.ToString();
        //countText.text = "Player 1 Count: " + count.ToString();
        if (count >= 6) 
        {
            winText.text = "You Win!";
            Invoke("Restart", 2.0f);
        }
    }

    //Player 1 Code with aswd keys
    void Player1Movement()
    {
        if (Input.GetKey(KeyCode.A))
        {
            // rb.AddForce(Vector3.left * speed);
            run();
        }

        if (Input.GetKey(KeyCode.D))
        {
            // rb.AddForce(Vector3.right * speed);
            run();
        }

        if (Input.GetKey(KeyCode.W))
        {
            // rb.AddForce(Vector3.forward * speed);
            run();
        }

        if (Input.GetKey(KeyCode.S))
        {
            // rb.AddForce(Vector3.back * speed);
            run();
        }

        if (Input.GetKeyDown("space"))
        {
            run();
        }
    }

    void run()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);

        // rb.AddForce(movement * speed);
        // rb.AddForce(movement * speed * Time.deltaTime);
        rb.AddForce(movement * speed );

        if (Input.GetKeyDown("space") && rb.transform.position.y <= 0.6250001f)
        {
            Vector3 jump = new Vector3(0.0f, force, 0.0f);
            rb.AddForce(jump);
        }
    }

    void setTimer()
    {
        if (timeRemaining > 0)
        {
            // timeRemaining -= Time.deltaTime;
            // timerText.text = "Time remaining: " + timeRemaining.ToString();
            timeRemaining -= Time.deltaTime;
            DisplayTime(timeRemaining);

            if(timeRemaining < 20)
            {
                AlertText.text = "Times almost up!";
            }
        } else
        {
            timerText.text = "Game Over!";
            timeRemaining = 0;
            timerIsRunning = false;
            Invoke("Restart", 2.0f);
        }
    }

    void DisplayTime(float timeToDisplay)
    {
        timeToDisplay += 1;

        float minutes = Mathf.FloorToInt(timeToDisplay / 60);
        float seconds = Mathf.FloorToInt(timeToDisplay % 60);

        timerText.text = "Time: " + string.Format("{0:00}:{1:00}", minutes, seconds);
    }

    //If your GameObject starts to collide with another GameObject with a Collider
    void OnCollisionEnter(Collision collision)
    {
        // Output the Collider's GameObject's name
        Debug.Log(collision.collider.name);

        if (collision.collider.name == "North Walls" || collision.collider.name == "South Walls" || collision.collider.name == "East Walls" || collision.collider.name == "West Walls")
        {
            wallCollissionCount = wallCollissionCount + 1;
            this.SetCountText();
            CollisionText.text = "Collision with " + collision.collider.name;
        }

        if(collision.collider.name == "Player2")
        {
            playerCollissionCount += 1;
            this.SetCountText();
            CollisionText.text = "Collision with Player 2";
        }
    }

    void Restart()
    {
        SceneManager.LoadScene("MiniGame");
    }
   
}
